See http://docs.codehaus.org/display/SONAR/Extending+Coding+Rules
